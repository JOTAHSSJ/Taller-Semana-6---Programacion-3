public class Nodo {
    public int dato;
    public Nodo sig;

    public Nodo(int dato) {
        this.dato = dato;
        this.sig = sig;
    }
}
